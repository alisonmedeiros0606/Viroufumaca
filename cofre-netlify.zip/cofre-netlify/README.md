# Cofre na Netlify, com cotações reais (brapi.dev)

Pasta pronta para publicar: o app (index.html) + duas funções que falam com a brapi.

## Como publicar
1. Crie uma conta em https://brapi.dev e copie o seu token.
2. Suba esta pasta para um repositório no GitHub (ou use o Netlify CLI: `npm i -g netlify-cli`, `netlify deploy --prod`).
3. Na Netlify: Add new site > Import an existing project > escolha o repositório. Não precisa de comando de build.
4. Em Site configuration > Environment variables, crie `BRAPI_TOKEN` com o seu token e faça um novo deploy.
5. Teste no navegador:
   - `https://SEU-SITE.netlify.app/api/search?q=pet`
   - `https://SEU-SITE.netlify.app/api/quote?t=PETR4`

## O que cada parte faz
- `/api/search`: lista ativos da bolsa enquanto o cliente digita 1, 2 ou 3 letras.
- `/api/quote`: devolve preço atual, variação do mês, variação de 12 meses e proventos médios por mês. O app usa isso no Início, na Análise e no Simulador.
- O token fica só na Netlify. Ele nunca vai para o navegador do cliente.
- As respostas ficam em cache (5 minutos para cotações, 1 hora para busca), o que reduz as chamadas à brapi.

## Pontos para conferir (não consegui testar com a brapi de verdade)
- Os nomes dos campos da resposta da brapi (`stocks`, `historicalDataPrice`, `dividendsData.cashDividends`) e os parâmetros de `/api/quote/list` estão na documentação em https://brapi.dev/docs. Se algo vier vazio, ajuste os nomes nos dois arquivos.
- Veja no site da brapi quais ativos e quantas consultas cada plano permite, e se ETFs e BDRs entram no seu plano.
- Renda fixa (Tesouro, CDB, LCI) e previdência não vêm da brapi. Nesses, o cliente informa o valor atual.
